from PyQt5 import QtCore, QtWidgets

from component import widget
from model import vo


class KanbanBoard(QtWidgets.QMainWindow):
    add_task_signal = QtCore.pyqtSignal(vo.Task)
    delete_task_signal = QtCore.pyqtSignal(vo.Task)
    reallocate_task_signal = QtCore.pyqtSignal(vo.Task, str)

    def __init__(self, kanbanboard):
        super().__init__()

        self._kanbanboard = kanbanboard

        self.setWindowTitle("KanbanBoard")

        # TODO 사이즈 자동 조정
        self.resize(1920, 1080)

        self.initUI()
        self.addConnection()

    def initUI(self):
        layout = QtWidgets.QVBoxLayout()

        self.kanban_widget = widget.KanbanBoard(self._kanbanboard)

        scroll_widget = QtWidgets.QScrollArea()
        scroll_widget.setWidget(self.kanban_widget)
        layout.addWidget(scroll_widget)

        self.setCentralWidget(scroll_widget)

    def addConnection(self):
        self.kanban_widget.add_task_signal.connect(self.add_task_signal)
        self.kanban_widget.delete_task_signal.connect(self.delete_task_signal)
        self.kanban_widget.reallocate_task_signal.connect(self.reallocate_task_signal)

    def refresh(self):
        self.initUI()
        self.addConnection()
