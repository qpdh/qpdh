import sys

from controller.main_controller import KanbanBoardController


if __name__ == "__main__":
    controller = KanbanBoardController()
    sys.exit(controller.run())
