import uuid
from collections import defaultdict
from datetime import datetime


class Task:
    def __init__(
        self,
        task_name: str,
        creator: str,
        status: str = "대기 중",
        priority: int = 0,
        evaluation_score: int = 0,
        public: bool = False,
    ):
        self.task_id = uuid.uuid4().int

        self.task_name = task_name  # 태스크 이름
        self.status = status  # 태스크 상태
        self.creator = creator  # 생성자

        self.priority = priority  # 우선순위
        self.evaluation_score = evaluation_score  # 평가 점수

        self.public = public  # 공개 옵션 (전체 공개, 담당자 공개)

        self.start_date = datetime.now()  # 시작 날짜
        self.end_date = datetime.now()  # 끝 날짜

    def __eq__(self, other):
        if not isinstance(other, Task):
            return False
        return other.task_id == self.task_id

    def __hash__(self):
        return self.task_id

    def __repr__(self):
        return str(self.__dict__)

    def change_status(self, status: str):
        self.status = status


class KanbanBoard:
    def __init__(self):
        super().__init__()

        self._board_id = uuid.uuid4().int
        self._allocations: dict[str, list] = defaultdict(list)  # type: dict(set[Task])

    @property
    def allocations(self):
        return self._allocations

    def get_statuses(self):
        return list(self._allocations.keys())

    def get_tasks(self, status: str):
        return self._allocations.get(status)

    def get_items(self):
        return self._allocations.items()

    def get_allocated_quantity(self, status: str) -> int:
        return len(self._allocations.get(status))

    def _can_reallocate(self, task: Task, status: str):
        return True

    def _can_allocate(self, task: Task, status: str):
        return True

    def __eq__(self, other):
        if not isinstance(other, KanbanBoard):
            return False
        return other._board_id == self._board_id

    def __hash__(self):
        return self._board_id
