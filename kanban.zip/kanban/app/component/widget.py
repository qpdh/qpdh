from datetime import datetime
from typing import List
from PyQt5 import QtWidgets, QtCore

from model import vo
from component import dialog


class Task(QtWidgets.QWidget):
    delete_task_signal = QtCore.pyqtSignal(vo.Task)
    reallocate_task_signal = QtCore.pyqtSignal(vo.Task, str)

    def __init__(self, task: vo.Task):
        super().__init__()

        self.task = task

        self.layout = QtWidgets.QVBoxLayout()

        self.task_name = QtWidgets.QLabel(f"✅ {self.task.task_name}")
        self.infoButton = QtWidgets.QPushButton("상세보기")
        self.infoButton.clicked.connect(lambda: self.show_task(self.task))

        ########
        # Date #
        ########
        dateWidget = self.createDateWidget(self.task.start_date, self.task.end_date)

        self.layout.addWidget(self.task_name)
        self.layout.addWidget(dateWidget)
        self.layout.addWidget(self.infoButton)

        self.setLayout(self.layout)

    def createDateWidget(self, start_date: datetime, end_date: datetime):
        start_date = start_date.strftime("%Y-%m-%d")
        end_date = end_date.strftime("%Y-%m-%d")

        dateWidget = QtWidgets.QLabel(f"📆 {start_date} ~ {end_date}")

        return dateWidget

    def show_task(self, task):
        task_dialog = dialog.TaskInfo(task, self)
        task_dialog.delete_task_signal.connect(self.delete_task_signal)
        task_dialog.reallocate_task_signal.connect(self.reallocate_task_signal)

        task_dialog.exec()


class KanbanElement(QtWidgets.QWidget):
    delete_task_signal = QtCore.pyqtSignal(vo.Task)
    reallocate_task_signal = QtCore.pyqtSignal(vo.Task, str)

    def __init__(self, tasks: set[vo.Task], status: str):
        super().__init__()

        self.layout = QtWidgets.QVBoxLayout()

        ################
        # Kanban Title #
        ################

        title_layout = QtWidgets.QHBoxLayout()
        title_layout.addWidget(QtWidgets.QLabel(status))

        ##################
        # Kanban Element #
        ##################
        kanbanElement = self.createKanbanElement(tasks, status)

        ##############
        # Add Layout #
        ##############

        self.layout.addWidget(kanbanElement)

        self.layout.addStretch()

        self.setLayout(self.layout)

    def createKanbanElement(self, tasks: set[vo.Task], status):
        kanbanElement = QtWidgets.QGroupBox(status)

        layout = QtWidgets.QVBoxLayout()

        for task in tasks:
            task_widget = Task(task)

            task_widget.delete_task_signal.connect(self.delete_task_signal)
            task_widget.reallocate_task_signal.connect(self.reallocate_task_signal)

            layout.addWidget(task_widget)

        kanbanElement.setLayout(layout)

        return kanbanElement


class KanbanBoard(QtWidgets.QWidget):
    add_task_signal = QtCore.pyqtSignal(vo.Task)
    delete_task_signal = QtCore.pyqtSignal(vo.Task)
    reallocate_task_signal = QtCore.pyqtSignal(vo.Task, str)

    def __init__(self, kanban_board: QtCore.QObject):
        super().__init__()

        self.kanban_board = kanban_board

        #########
        # Title #
        #########
        title_layout = QtWidgets.QHBoxLayout()
        title_layout.addWidget(QtWidgets.QLabel("Kanban Board"))
        add_button = QtWidgets.QPushButton("➕ 태스크 생성")
        add_button.clicked.connect(self.show_add_dialog)
        title_layout.addWidget(add_button)
        title_layout.addStretch()

        ########
        # Main #
        ########
        main_layout = QtWidgets.QHBoxLayout()
        for status, tasks in self.kanban_board.items():
            kanban_element = KanbanElement(tasks, status)
            kanban_element.delete_task_signal.connect(self.delete_task_signal)
            kanban_element.reallocate_task_signal.connect(self.reallocate_task_signal)
            main_layout.addWidget(kanban_element)

        ##############
        # Add Layout #
        ##############
        layout = QtWidgets.QVBoxLayout()
        layout.addLayout(title_layout)
        layout.addLayout(main_layout)

        self.setLayout(layout)

    def show_add_dialog(self):
        add_task_dialog = dialog.AddTask(self)
        add_task_dialog.add_task_signal.connect(self.add_task_signal)

        ##############
        # Add Signal #
        ##############

        add_task_dialog.exec()
