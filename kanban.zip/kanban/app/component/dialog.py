from PyQt5 import QtWidgets, QtCore

from model import vo
from resource import conf


class TaskInfo(QtWidgets.QDialog):
    delete_task_signal = QtCore.pyqtSignal(vo.Task)
    reallocate_task_signal = QtCore.pyqtSignal(vo.Task, str)

    def __init__(self, task: vo.Task, parent):
        super().__init__(parent)

        layout = QtWidgets.QVBoxLayout()

        ########
        # Form #
        ########
        formLayout = QtWidgets.QFormLayout()

        status = QtWidgets.QComboBox()
        status.addItems(conf.STATUS_CATEGORY)
        status.setCurrentText(task.status)
        status.currentTextChanged.connect(
            lambda: self.changeStatus(task, status.currentText())
        )

        date = QtWidgets.QWidget()
        dateLayout = QtWidgets.QVBoxLayout()
        dateLayout.addWidget(QtWidgets.QLabel(task.start_date.strftime("%Y-%m-%d")))
        dateLayout.addWidget(QtWidgets.QLabel(task.end_date.strftime("%Y-%m-%d")))
        dateLayout.addStretch()
        date.setLayout(dateLayout)

        formLayout.addRow(QtWidgets.QLabel("상태"), status)
        formLayout.addRow(QtWidgets.QLabel("일정"), date)

        formLayout.addRow(
            QtWidgets.QLabel("생성자"), QtWidgets.QLabel(f"😀 {task.creator}")
        )

        ########
        # Main #
        ########
        mainLayout = QtWidgets.QVBoxLayout()

        self.deleteButton = QtWidgets.QPushButton("제거")

        self.deleteButton.clicked.connect(lambda: self.deleteButtonClick(task))

        mainLayout.addWidget(QtWidgets.QLabel(task.task_name))
        mainLayout.addLayout(formLayout)
        mainLayout.addWidget(self.deleteButton)

        ##############
        # Add Layout #
        ##############
        layout.addLayout(mainLayout)

        self.setLayout(layout)

        self.setWindowTitle("Task Info")

    def changeStatus(self, task: vo.Task, status: str):
        self.reallocate_task_signal.emit(task, status)

    def deleteButtonClick(self, task: vo.Task):
        self.delete_task_signal.emit(task)


class AddTask(QtWidgets.QDialog):
    add_task_signal = QtCore.pyqtSignal(vo.Task)

    def __init__(self, parent):
        super().__init__(parent)

        layout = QtWidgets.QVBoxLayout()

        #########
        # Title #
        #########
        title_layout = QtWidgets.QVBoxLayout()

        title_layout.addWidget(QtWidgets.QLabel("태스크 생성"))
        title_layout.addStretch()

        ########
        # Form #
        ########
        form_layout = QtWidgets.QFormLayout()

        self.task_name = QtWidgets.QLineEdit()
        self.status = QtWidgets.QComboBox()
        self.status.addItems(conf.STATUS_CATEGORY)

        self.priority = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.priority.setRange(0, 100)

        self.evaluation_score = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.evaluation_score.setRange(0, 10)

        self.public = QtWidgets.QLineEdit()
        self.add_button = QtWidgets.QPushButton("추가")

        self.add_button.clicked.connect(
            lambda: self.add_button_click(
                vo.Task(
                    task_name=self.task_name.text(),
                    creator="테스트",  # TODO creator
                    status=self.status.currentText(),
                    priority=self.priority.value(),
                    evaluation_score=self.evaluation_score.value(),
                    public=self.public.text(),
                )
            )
        )

        form_layout.addRow(QtWidgets.QLabel("task_name:"), self.task_name)
        form_layout.addRow(QtWidgets.QLabel("status:"), self.status)
        form_layout.addRow(QtWidgets.QLabel("priority:"), self.priority)
        form_layout.addRow(QtWidgets.QLabel("evaluation_score:"), self.evaluation_score)
        form_layout.addRow(QtWidgets.QLabel("public:"), self.public)
        form_layout.addWidget(self.add_button)

        ########
        # Main #
        ########
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addLayout(form_layout)

        ##############
        # Add Layout #
        ##############
        layout.addLayout(title_layout)
        layout.addLayout(main_layout)

        self.setLayout(layout)

        self.setWindowTitle("Add Task")

    def add_button_click(self, task: vo.Task):
        # TODO 입력 값 검증
        self.add_task_signal.emit(task)
