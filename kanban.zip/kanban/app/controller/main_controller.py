import sys
from PyQt5 import QtWidgets, QtCore

from model import vo
from service import main_service
from view import main_view


class KanbanBoardController:
    def __init__(self):
        self._app = QtWidgets.QApplication(sys.argv)

        self._kanbanboard_service = main_service.KanbanBoard()

        ####################
        # TODO DELETE TEST #
        ####################
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크", "dhkim"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크", "dhkim", "진행 중"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크2", "dhkim", "진행 중"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크2", "dhkim", "진행 중"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크2", "dhkim", "진행 중"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크2", "dhkim", "진행 중"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크", "dhkim", "완료"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크", "dhkim", "이슈"))
        self._kanbanboard_service.allocate(vo.Task("테스트 테스크", "dhkim", "홀드"))

        self._kanbanboard_view = main_view.KanbanBoard(
            self._kanbanboard_service.allocations
        )

        self.init()

    def init(self):
        self._kanbanboard_view.add_task_signal.connect(self.allocate_task)
        self._kanbanboard_view.delete_task_signal.connect(self.delete_task)
        self._kanbanboard_view.reallocate_task_signal.connect(self.reallocate_task)

    def allocate_task(self, task: vo.Task):
        self._kanbanboard_service.allocate(task)
        self._kanbanboard_view.refresh()

    def reallocate_task(self, task, status):
        self._kanbanboard_service.reallocate(task, status)
        self._kanbanboard_view.refresh()

    def delete_task(self, task: vo.Task):
        self._kanbanboard_service.deallocate(task)
        self._kanbanboard_view.refresh()

    def run(self):
        self._kanbanboard_view.show()
        return self._app.exec_()
