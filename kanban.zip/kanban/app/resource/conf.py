STATUS_CATEGORY = ["대기 중", "진행 중", "완료", "이슈", "홀드"]
